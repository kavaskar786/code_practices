const Footer = () => {
  return (
    <div className="flex items-center justify-center h-[8vh] bg-[#212835] w-[100%] text-white shadow-upShadow">
      <p>@ kavaskar's work</p>
    </div>
  );
};
export default Footer;
